from setuptools import setup

setup(name='PRPS',
      version='0.0.1',
      description='A package for allowing Pepper to play rock-paper-scissors',
      url='https://github.com/D7017E/Rock-Paper-Scissors',
      author='bersim',
      author_email='bersim-8@student.ltu.se',
      license='Apache',
      packages=['PRPS'],
      zip_safe=False)